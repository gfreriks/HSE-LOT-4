<map version="0.9.0">
<!-- Freemind mindmap generated with LinkEHR editor (www.linkehr.com) on Wed May 28 13:36:42 CEST 2014 -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1401277002621" MODIFIED="1401277002621" POSITION="right">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>A0-epSOSPatientSummaryUC</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p>epSOSPatientSummaryUC
GUIDELINES ON MINIMUM/NON- EXHAUSTIVE PATIENT SUMMARY DATASET FOR ELECTRONIC EXCHANGE IN ACCORDANCE WITH THE CROSS-BORDER DIRECTIVE 2011/24/EU
RELEASE 1</p>
</body></html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="report"/>
<node CREATED="1401277002621" FOLDED="true" ID="DESCRIPTION" MODIFIED="1401277002621" TEXT="DESCRIPTION" POSITION="left">
<icon BUILTIN="pencil"/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="original_author">
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="email: g.freriks@e-recordservices.eu"/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="name: Gerard Freriks"/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="organisation: ERS B.V."/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="date: 20140521"/>
</node>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="lifecycle_state: Draft"/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="purpose: Specify the epSOS Patient Summary for Unplanned Care as defined bythe  EU Guideline:
GUIDELINES ON MINIMUM/NON- EXHAUSTIVE PATIENT SUMMARY DATASET FOR ELECTRONIC EXCHANGE IN ACCORDANCE WITH THE CROSS-BORDER DIRECTIVE 2011/24/EU
RELEASE 1"/>
<node CREATED="1401277002621" FOLDED="true" MODIFIED="1401277002621" TEXT="keywords">
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="epSOS"/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="PatientSummary"/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="UnplannedCare"/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="Release 1"/>
</node>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="use: To exchange the data set as specified by the EU guideline.
This Subject Area Model for the Patient Summary is clinically validated.
As the result of implementation this specification needs to be refined.
As much as possible codes have been added to the nodes in the SAM."/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="misuse: Planned care"/>
<node CREATED="1401277002621" MODIFIED="1401277002621" TEXT="copyright: In accordence with HSE STANDARD TERMS FOR INFORMATION COMMUNICATIONS TECHNOLOGY SUPPLIES AND SERVICES: HSE for this Proof of Concept deliverable of ISF LOT 4: INFORMATION ARCHITECTURE"/>
</node>
<node CREATED="1401277002621" MODIFIED="1401277002621" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A1-Patient Administrative Data</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Patient Administrative data that identifies a person]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A1-PatientAdministrativeData]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D0-PatientSummaryDocument</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specifies PS Document related data</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::D0-PatientSummaryDocument][SNOMED-CT::116154003][SNOMED-CT::371534008]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D1-Country</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Name of Country A]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::D1-Country][SNOMED-CT::223369002]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D1-Country</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[epSOS::D1-Country]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D2-PatientSummaryDocument</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::D2-PatientSummaryDocument][SNOMED-CT::116154003][SNOMED-CT::422735006]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D2.1-DateCreated</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Date on whichPS was generated</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::D2.1-DateCreated][SNOMED-CT::129376004][SNOMED-CT::410671006]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D2.1-DateCreated</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::D2.1-DateCreated]</p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D2.2-DateOfLastUpdate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Date on which PS was updated (date of most recent version)]</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::D2.2-DateOfLastUpdate][SNOMED-CT::83324001]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D2.2-DateOfLastUpdate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::D2.2-DateOfLastUpdate]</p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D3.1-NatureOfPS</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Defines the context in which it was generated:
- Human
- Automated
- Human and Automated]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::D3.1-NatureOfPS]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D3.1-NatureOfPS</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Human, Automated, HumanAndAutomated]</p>
&#xa;
<p align="left">[epSOS::D3.1-NatureOfPS]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D4.1-AuthorOrganisation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[At least one author or organisation (HCP) shall be listed. If there is no HCP, at least one HP shall be listed.]</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::D4.1-AuthorOrganisation][SNOMED-CT::37920003]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>D4.1-AuthorOrganisation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[epSOS::D4.1-AuthorOrganisation][SNOMED-CT::21139007][SNOMED-CT::37920003]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A1-A2-PersonalInformationIdentification</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[SubjectOfCare conatins the Identifiers and personal information]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A1-A2-PersonalInformationIdentification][DCM::CEN-EN13606-ENTRY.SubjectOfCare.v1][SIAMMR3::ENTRY.MPF][ContSys::SubjectOfCare]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002636" MODIFIED="1401277002636" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: SubjectOfCare Original text: [SubjectOfCare]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType][ContSys::HealthcareActor][ContSys::SubjectOfCare]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A1-PersonalInformationIdentification</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A1-PersonalInformationIdentification][SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A2-PersonalInformation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOLOCharacteristics

=&amp;gt; NO SNOMED CODE for Characteristics of a Linving object &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A2-PersonalInformation][SIAMMR3::NOLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; NO SNOMED CODE for the Name of a person that is not a patient And thereor for all subordinate items&amp;lt;=

ISO:22220
Code for Name related topics of a Living Object:
	•	Name Use Group
	•	Name FamilyName Group
  	•	Name GivenNameGroup    
	•	Name Title group
	•	Name Prefix group
	•	Name Suffix Group
	•	Name Preferred Flag
	•	Name Conditional  Use
As many times LOName can be invoked as necessary.
The Preferred Flag indicates the preferred name.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A2.1-Fullname</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO:22220

Codes for a Family name
</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::A2.1-Fullname][SIAMMR3::NOLONameFamilyGroup]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A2.1.1-FamilyName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Family Names

[This field can contain more than one element. Example: espanol SMith
Note: some countries require surnames to be birth name [to avoid potential problems with married women&amp;apos;s surnames]]

=&amp;gt; There is NO SNOMED code for NAME of a person &amp;lt;=


</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::A2.1.1-FamilyName][SIAMMR3::NOLONameFamilyName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Family Names
=&amp;gt; Tere is NO SNOMED code for NAME of a person &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::NOLONameFamilyName]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLONameFamilyNameSequenceNumber]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLONameFamilyNameSequenceNumber]</p>
</body>
</html></richcontent>
<icon BUILTIN="numero"/>
</node>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A2.1-GivenName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[The first name of the patient (example: John)
This field can contain more than one element]</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::A2.1-GivenName][SIAMMR3::NOLONameGivenGroup]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A2.1.1-GivenName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Given Names

[The first name of the patient (example: John)
This field can contain more than one element]

There is NO SNOMED code for &amp;apos;Given Name&amp;apos; or &amp;apos;First Name&amp;apos;</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A2.1.1-GivenName][LOINC::45392-8][SIAMMR3::NOLONameGivenName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Given Names</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SNOMED-CT::184095009][SIAMMR3::NOLONameGivenName]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLONameGivenNameSequenceNumber]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLONameGivenNameSequenceNumber]</p>
</body>
</html></richcontent>
<icon BUILTIN="numero"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLODemographics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220 (extended)

Codes for characteristics of Living Objects.
E.g. Name, Demographics, Biometrics

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::302147001][SIAMMR3::NOLODemographics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A2.3-Gender</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left"> ISO:22220 (Extension)

[This field must contain a recognized valid value.]


1- Male
2- Female
3- Intersex / indeterminate

9- Not stated / inadequately described</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A2.3-Gender][SNOMED-CT::263495000][SIAMMR3::NOLODAdministrativeGender]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLODAdministrativeGender</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO:22220 (Extension)
The sex of the subject as used for administrative purposes.

1- Male
2- Female
3- Intersex / indeterminate

9- Not stated / inadequately described
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Male, Female, Intersex, Not stated / inadequately described]</p>
&#xa;
<p align="left">[SNOMED-CT::263495000][SIAMMR3::NOLODAdministrativeGender]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Male</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::10052007]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Female</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::1086007]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Intersex</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::15867007]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NotStated</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NotStated or Inadequatley described</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::260415000]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLODBirthDetails</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">No LOINcode for &amp;apos;Birth details&amp;apos;</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::169811007][SIAMMR3::NOLODBirthDetails]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A2.2-DateOfBirth</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[This field may contain only the year if the day and month are not available, e.g. 01/01/2009]

There is NO SNOMED code for &amp;apos;Date of Birth&amp;apos;</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[LOINC::54124-3][SIAMMR3::NOLODBirthDate]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLODBirthDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLODBirthDate]</p>
</body>
</html></richcontent>
<icon BUILTIN="datetime"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002652" MODIFIED="1401277002652" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A1.1-NationalHealthcarePatientID</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left"> CLUSTER that codes for the set of Unique Identifiers and their attributes for this entity

[Country ID, unique to the patient in that country. Example: ID for United Kingdom patient]

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A1.1-NationalHealthcarePatientID][SIAMMR3::NOUniqueIdentifiers]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A1.1.1-NationalHealthcarePatientID</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.2: SubjectIdentifier

[Country ID, unique to the patient in that country. Example: ID for United Kingdom patient]
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A1.1.1-NationalHealthcarePatientID][SIAMMR3::NOUIDDesignation]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDDesignation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.2: SubjectIdentifier</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::NOUIDDesignation]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.5: SubjectIdentifier Type

[Example: QQ 12 34 56 A]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOUIDType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.5: SubjectIdentifier Type

Codes for type of user/service/etc.</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: NationalHcID Original text: [NationalHcID]</p>
&#xa;
<p align="left">[SIAMMR3::NOUIDType]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A4.1-InsuranceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Example: QQ 12 34 56 A]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOUniqueIdentifiers]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A4.1.1-InsuranceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Example: QQ 12 34 56 A]

There is NO SNOMED or LOINC code for &amp;apos;Insurance number&amp;apos;</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A4.1.1-InsuranceNumber][SIAMMR3::NOUIDDesignation]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A4.1.1-InsuranceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Example: QQ 12 34 56 A]</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOUIDType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Participations</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Participations

Links to actors related to the Subject of Care: Contact person/ legal guardian
(if available)

=&amp;gt; NO SNOMED CODE to indocate Participation of one entity to an other &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.Participations.v2][SIAMMR3::Participations]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>POtherEntities</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">CLUSTER model that codes for the participation of any actor not being the HcP or SubjectOfCare.

=&amp;gt; There is NO SNOMED code for Healthcare actor &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::POtherEntities]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.5.1-PersonRole</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Role Code Set for Subjects: 13606-3 Termlist Subject_Catagory
patient DS01
relative of patient DS01
foetus or neonate
mother
donor
other person
body part or specimen
device or implant or prosthesis
other entity
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.5.1-PersonRole][SIAMMR3::POERole]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>POERole</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Role Code Set for Subjects: 13606-3 Termlist Subject_Catagory
DS00- patient
DS01- relative of patient
DS02- foetus or neonate
DS03- mother
DS04- donor
DS06- other person
DS07- body part or specimen
DS08- device or implant or prosthesis
DS05- other entity
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [LagalGardien, ContactPerson]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Coded value 1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_yellow"/>
</node>
</node>
</node>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.5-ContactPersonLegalGuardian</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos; Object &amp;apos; &amp;lt;=

Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.5-ContactPersonLegalGuardian][SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v3][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOLOCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for Characteristics of a Living object &amp;lt;=
=&amp;gt; NO SNOMED PRIMITIVE for &amp;apos;Characteristics&amp;apos; of a Living Object&amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NOLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; NO SNOMED PRIMITIVE for the Name of a person that is not a patient And thereor for all subordinate items&amp;lt;=

ISO:22220
Code for Name related topics of a Living Object:
	•	Name Use Group
	•	Name FamilyName Group
  	•	Name GivenNameGroup    
	•	Name Title group
	•	Name Prefix group
	•	Name Suffix Group
	•	Name Preferred Flag
	•	Name Conditional  Use
As many times LOName can be invoked as necessary.
The Preferred Flag indicates the preferred name.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[LOINC::52458-7][SIAMMR3::NOLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyGroup</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[This field can contain more than one element. Example: Espa&amp;ntilde;ol Smith]

=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Name&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos; Family;  &amp;lt;=
=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos; Name&amp;apos; &amp;lt;=

ISO:22220

Codes for a Family name
</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[SNOMED-CT::35359004][SIAMMR3::NOLONameFamilyGroup]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.5.3-FamilyNameContact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Family Names

=&amp;gt; There is NO SNOMED code for NAME of a person &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::A3.5.3-FamilyNameContact][SIAMMR3::NOLONameFamilyName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Family Names
=&amp;gt; Tere is NO SNOMED code for NAME of a person &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLONameFamilyNameSequenceNumber]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="numero"/>
</node>
</node>
</node>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.5.2-GivenNameContact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[The first name of the contact person/guardian (example: Peter). This field can contain more than one element.]</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[epSOS::A3.5.2-GivenNameContact][SIAMMR3::NOLONameGivenGroup]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Given Names</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::184095009][LOINC::45392-8][SIAMMR3::NOLONameGivenName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Given Names</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SNOMED-CT::184095009]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLONameGivenNameSequenceNumber]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002667" MODIFIED="1401277002667" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="numero"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOtherAddress</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOOtherAddress

=&amp;gt; No SNOMED code for any(patient or other person or object) digital address &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOtherAddress]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOAdigitalCommunication</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220
Codes or any Digital Address
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunication]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationMedium</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; NO SNOMD CODE for &amp;apos;Communicatio Medium&amp;apos;

ISO: 22220

A code representing a type of communication mechanism used by a subject of care.
1- Telephone (Landline)
2- Telephone Mobile
3- Fax
4- Pager
5- e-mail
6- URL

8- Other


See 13606-3TermList also</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunicationMedium]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationMedium</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Telehone</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::359993007]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Mobile</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED code for general Mobile Telephone &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Fax</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD

=&amp;gt; There is NO SNOMED general code for Fax &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>eMail</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD

=&amp;gt; There NO SNOMD code for eMail &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>URL</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD
=&amp;gt; There is NO SNOMED code for URL &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Coded value 6</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::74964007]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.5.4-TelephoneContact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO:22220

[Example: +45 20 7025 6161]

A code representing the manner of use that a person applies to an electronic communication medium.

1- Business
2- Personal
3- Both
3-
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.5.4-TelephoneContact][SIAMMR3::NOOAAddressDigitalCommunicationUsageCode]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOAAddressDigitalInformationUsageCode</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOAdigitalCommunication</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[e-mail of the contact person/legal guardian]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOAdigitalCommunication]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.5.5-eMailContact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[e-mail of the contact person/legal guardian]</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[epSOS::A3.5.5-eMailContact][SIAMMR3::NOOAAddressDigitalCommunicationUsageCode]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOAAddressDigitalInformationUsageCode</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationMedium</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunicationMedium]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationMedium</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3-ContactInformation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ContactInformation</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::HcProvider][epSOS::A3-ContactInformation][DCM::CEN-EN13606-ENTRY.HcProvider.v3][SIAMMR3::ENTRY.MPF]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Folder, Composition, Section, Entry, Cluster, Element, EHR-Extract]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation, Evaluation, Instruction, Action]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: HcProvider Original text: [HcProvider]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType][ContSys::HealthcareActor][ContSys::HealthcareProvider]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Order, Execute, Assess, ResultCollection, Inference]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Diagnostic, Therapeutic, Administrative, Management, ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4-PreferredHP-HPOContact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOLOCharacteristics

=&amp;gt; NO SNOMED CODE for Characteristics of a Linving object &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4-PreferredHP</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOLOName

The Preferred Provider</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.4-PreferredHP][DCM::CEN-EN13606-CLUSTER.NOLOName.v1][LOINC::52458-7][SIAMMR3::NOLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4-FamilyNameHP</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Name of the HP/ HPO that has been treating the patient. If this is an HP, the structure of the name will be the same as described in ‘Full name’ (given name, family name/surname).]


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Name&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos; Family;  &amp;lt;=
=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos; Name&amp;apos; &amp;lt;=

ISO:22220

Codes for a Family name
</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::A3.4-FamilyNameHP][SNOMED-CT::35359004][SIAMMR3::NOLONameFamilyGroup]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4.1-FamilyNameHP</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Family Names

[Name of the HP/ HPO that has been treating the patient. If this is an HP, the structure of the name will be the same as described in ‘Full name’ (given name, family name/surname).]

=&amp;gt; There is NO SNOMED code for NAME of a person &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.4.1-FamilyNameHP][SIAMMR3::NOLONameFamilyName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Family Names
=&amp;gt; Tere is NO SNOMED code for NAME of a person &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLONameFamilyNameSequenceNumber]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameFamilyNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="numero"/>
</node>
</node>
</node>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4-HPGivenName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::A3.4-HPGivenName][SIAMMR3::NOLONameGivenGroup]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002683" MODIFIED="1401277002683" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4.2-HPGivenName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Given Names</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.4.2-HPGivenName][SNOMED-CT::184095009][LOINC::45392-8][SIAMMR3::NOLONameGivenName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
One of the  Given Names</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SNOMED-CT::184095009]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOLONameGivenNameSequenceNumber]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOLONameGivenNameSequenceNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 22220
Codes for the sequence number 1, 2, 3, …)</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="numero"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOtherAddress</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOOtherAddress

=&amp;gt; No SNOMED code for any(patient or other person or object) digital address &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOtherAddress]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunication</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220
Codes or any Digital Address
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunication]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationMedium</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; NO SNOMD CODE for &amp;apos;Communicatio Medium&amp;apos;

ISO: 22220

A code representing a type of communication mechanism used by a subject of care.
1- Telephone (Landline)
2- Telephone Mobile
3- Fax
4- Pager
5- e-mail
6- URL

8- Other


See 13606-3TermList also</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunicationMedium]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationMedium</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: Telephone Original text: [Telephone]</p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunicationMedium]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Telehone</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::359993007]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Mobile</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED code for general Mobile Telephone &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Fax</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD

=&amp;gt; There is NO SNOMED general code for Fax &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>eMail</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD

=&amp;gt; There NO SNOMD code for eMail &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>URL</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD
=&amp;gt; There is NO SNOMED code for URL &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Coded value 6</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">A default created CD</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::74964007]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_yellow"/>
</node>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4.3-Telephone</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO:22220

[Example: +45 20 7025 6161]

=&amp;gt; There is NO SNOMED code for &amp;apos;digital address&amp;apos; of anything &amp;lt;=

A unique combination of characters used as input to electronic telecommunication equipment for the purpose of contacting a subject of care.
	•	URI
	•	URL
	•	Tweet address
	•	Facebook address
	•	E-mail address
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::A3.4.3-Telephone][SIAMMR3::NOOADigitalCommunicationDetails]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationDetails</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO:22220
A unique combination of characters used as input to electronic telecommunication equipment for the purpose of contacting a subject of care.
	•	URI
	•	URL
	•	Tweet address
	•	Facebook address
	•	E-mail address
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [URI, URL, TweetAddress, FaceBookAddress]</p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunicationDetails]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunication</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunication]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4.4-eMail</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[e-mail of the HP/legal organization]</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunicationDetails][SIAMMR3::A3.4.4-eMail]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationDetails</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationMedium</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::NOOADigitalCommunicationMedium]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOOADigitalCommunicationMedium</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: eMail Original text: [eMail]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4-PreferredHPO</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.4-PreferredHPO][DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4-PreferredHP-HPOContact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.4-PreferredHP-HPOContact][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>A3.4.1-HcProviderOrganisation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Name of the HP/ HPO that has been treating the patient. If this is an HP, the structure of the name will be the same as described in ‘Full name’ (given name, family name/surname).]

=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::A3.4.1-HcProviderOrganisation][SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: HealthcareProviderOrganisation Original text: [HealthcareProviderOrganisation]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C-PatientClinicalData</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Sections that store the clinical relevant patient related data]</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1-Alerts</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.2-MedicalAlert</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Information (other alerts not included in Allergies</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C1.2-MedicalAlert]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.2-MedicalAlert</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">PhysicalFindingsVitalSigns</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::C1.2-MedicalAlert][DCM::CEN-EN13606-ENTRY.PrRcHealthObservationConditionAllergy.v1][SIAMMR3::ENTRY.MPF][SIAMMR3::PrRcHAssesedConditionMedicaAlert]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse][SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics

=&amp;gt; No codes for Characteristics of an OBJECT &amp;lt;=
&amp;gt; Organisation or Physical or non physical</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: HealthObservedCondition Original text: [HealthObservedCondition]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.2.1-HealthAlertDescription</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Description of the clinical manifestations of the allergic reaction.
Example: anaphylactic shock, angioedema (The clinical manifestation a;so gives information about the severity of the observed reaction)</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][DCM::CEN-EN13606-CLUSTER.ResultValues.v2][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.2.1-HealthAlertDescriptionID</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext

C1.2.1 and C1.2.2</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C1.2.1-HealthAlertDescriptionID][SIAMMR3::ResultCodedText]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext

HealthA;ert as text and with ID Code</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.1-Allergy</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.1-Allergy</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Assessed Condition</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::C1.1-Allergy][DCM::CEN-EN13606-ENTRY.PrRcHealthObservationConditionAllergy.v1][SIAMMR3::ENTRY.MPF][ContSys::PrRcAssesedConditionAllergy]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002699" MODIFIED="1401277002699" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse][SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics

=&amp;gt; No codes for Characteristics of an OBJECT &amp;lt;=
&amp;gt; Organisation or Physical or non physical</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: HealthObservedCondition Original text: [HealthObservedCondition]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.1.3-Onset date</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::C1.1.3-Onsetdate][SIAMMR3::NONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONFirstUseDate]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>DATE</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.1.1-AllergyDescription-Code</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Description of the clinical manifestations of the allergic reaction.
Example: anaphylactic shock, angioedema (The clinical manifestation a;so gives information about the severity of the observed reaction)]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C1.1.1-AllergyDescription-Code][SNOMED-CT::423100009][DCM::CEN-EN13606-CLUSTER.ResultValues.v2][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.1.2-ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Description of the clinical manifestations of the allergic reaction.
Example: anaphylactic shock, angioedema (The clinical manifestation a;so gives information about the severity of the observed reaction)]</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C1.1.2-ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Participations</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Participations

=&amp;gt; NO SNOMED CODE to indocate Participation of one entity to an other &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.Participations.v2][SIAMMR3::Participations]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.1.4-AgentCode</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">CLUSTER model that codes for the participation of any actor not being the HcP or SubjectOfCare.

[Describes the agent (drug, food, chemical agent, etc.) that is responsible for the adverse reaction]

=&amp;gt; There is NO SNOMED code for Healthcare actor &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C1.1.4-AgentCode][SIAMMR3::POtherEntities]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>POERole</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Role Code Set for Subjects: 13606-3 Termlist Subject_Catagory
patient DS01
relative of patient DS01
foetus or neonate
mother
donor
other person
body part or specimen
device or implant or prosthesis
other entity
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::POERole]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002714" MODIFIED="1401277002714" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>POERole</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Role Code Set for Subjects: 13606-3 Termlist Subject_Catagory
DS00- patient
DS01- relative of patient
DS02- foetus or neonate
DS03- mother
DS04- donor
DS06- other person
DS07- body part or specimen
DS08- device or implant or prosthesis
DS05- other entity
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: AssociatedAgent Original text: [AssociatedAgent]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos; Object &amp;apos; &amp;lt;=

Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v3][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics

=&amp;gt; No codes for Characteristics of an OBJECT &amp;lt;=
&amp;gt; Organisation or Physical or non physical</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C1.1.4-Agent</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Describes the agent (drug, food, chemical agent, etc.) that is responsible for the adverse reaction]

=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">[Describes the agent (drug, food, chemical agent, etc.) that is responsible for the adverse reaction]

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2-MedicalHistory</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.1-Vaccinations</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.1-Vaccination</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">MainPattern to be speialised</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[epSOS::C2.1-Vaccination][DCM::CEN-EN13606-ENTRY.PrHcRUHI.v2][SIAMMR3::ENTRY.MPF][SIAMMR3::ENTRY.PrHcRUHI]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName][ContSys::HealthIssue]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.1.2-BrandName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C2.1.2-BrandName][SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUniqueIdetifiers</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">  CLUSTER that codes for the set of Unique Identifiers and their attributes for this entity

=&amp;gt; There is NO SNOMED code for Unique and Identifier &amp;lt;=
&amp;gt; And the subordinate items  Designation/name, GeoArea, Issuer, Type

</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NOUniqueIdetifiers]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002730" MODIFIED="1401277002730" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.1.3-VaccinationIDCode</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.2: SubjectIdentifier
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C2.1.3-VaccinationIDCode][SIAMMR3::NOUIDDesignation]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002745" MODIFIED="1401277002745" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDDesignation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.2: SubjectIdentifier</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::NOUIDDesignation]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002745" MODIFIED="1401277002745" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.5: SubjectIdentifier Type

Codes for type of user/service/etc.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOUIDType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002745" MODIFIED="1401277002745" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.5: SubjectIdentifier Type

Codes for type of user/service/etc.</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: VaccinationIDCode Original text: [VaccinationIDCode]</p>
&#xa;
<p align="left">[SIAMMR3::NOUIDType]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002745" MODIFIED="1401277002745" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002745" MODIFIED="1401277002745" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>Vaccination</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Contains each disease against which the patient has been immunized

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002745" MODIFIED="1401277002745" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002745" MODIFIED="1401277002745" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOOtherCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOOtherCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for the general term &amp;apos;Characteristics&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.1.4-VaccinationDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;first&amp;apos; and &amp;apos;use&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C2.1.4-VaccinationDate][SNOMED-CT::419385000][SIAMMR3::NONLONFirstUseDate]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.2-PastProblems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Lisy of resolved, closed, or inactive problems</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.2-PastProblem</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">MainPattern to be speialised</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[epSOS::C2.2-PastProblem][DCM::CEN-EN13606-ENTRY.PrHcRUHI.v2][SIAMMR3::ENTRY.MPF]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: AssesedCondition Original text: [AssesedCondition]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002761" MODIFIED="1401277002761" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.2.2-ProblemDescriptionCode</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Problems o rdiagnosis not inclided in the definition of \&amp;quot; current problems or diagnosis&amp;apos; [Example: hepatic cyst. The patint has been treated with an hepatic cystectomy that solved the problem and closed the problem)

Descroption and Code are documented</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::C2.2.2-ProblemDescriptionCode][SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOOtherCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOOtherCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for the general term &amp;apos;Characteristics&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.2.4-EndDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;first&amp;apos; and &amp;apos;use&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::419385000][SIAMMR3::NONLONFirstUseDate]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.2.3-OnsetTime</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the date to be decomissioned

=&amp;gt; NO SNOMED CODE for &amp;apos;Decommission&amp;apos; of a &amp;apos;NonLiving Object&amp;apos; &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONDecommissionDate]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONDecommissionDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the date to be decomissioned
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.2.5-ResolutionCircumstance</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Describes the reason for which the status of the problem changed from current to inactive (e.g. surgical procedure, medical treatment, etc.). This field includes \\\\\\\\\\\\\&amp;quot;free text\\\\\\\\\\\\\&amp;quot; if the resolution circumstances are not already included in other fields such as surgical procedure, medical device, etc., e.g. hepatic cystectomy (this will be the resolution circumstances for the problem \\\\\\\\\\\\\&amp;quot;hepatic cyst\\\\\\\\\\\\\&amp;quot; and will be included in surgical procedures).

There are NO SNOMED and LOINC codes for &amp;apos;Resolution Circumstance&amp;apos;</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::C2.2.5-ResolutionCircumstance]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIMPLE_TEXT</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.3-PastSurgicalProcedures</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">List of Surgical procedures prior to the past six months</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.3-PastSurgicalProcedures</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">MainPattern to be speialised</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[epSOS::C2.3-PastSurgicalProcedures][DCM::CEN-EN13606-ENTRY.PrHcRUHI.v2][SIAMMR3::ENTRY.MPF]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: HealthcareActivity Original text: [HealthcareActivity]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002777" MODIFIED="1401277002777" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.3.1-ProcedureDescriptionID</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Describes the type of procedure
And Code ID</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C2.3.1-ProcedureDescriptionID][SNOMED-CT::71388002][LOINC::18836-7][SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOOtherCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOOtherCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for the general term &amp;apos;Characteristics&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C2.3.3-ProcedureDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;first&amp;apos; and &amp;apos;use&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C2.3.3-ProcedureDate][SNOMED-CT::419385000][SIAMMR3::NONLONFirstUseDate]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3-MedicalProblems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.1-CurrentProblems/Diagnosis</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">LIst of current Problems or Diagnosis</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.1-CurrentProblems/Diagnosis</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">MainPattern to be speialised</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::C3.1-CurrentProblemsDiagnosis][DCM::CEN-EN13606-ENTRY.PrHcRUHI.v2][SIAMMR3::ENTRY.MPF]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002792" MODIFIED="1401277002792" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: HealthIssue Original text: [HealthIssue]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Diagnostic, Therapeutic, Administrative, Management, ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.1.1-ProblemDiagnosis</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002808" MODIFIED="1401277002808" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOOtherCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOOtherCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for the general term &amp;apos;Characteristics&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.1.3-OnsetTime</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;first&amp;apos; and &amp;apos;use&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C3.1.3-OnsetTime][SNOMED-CT::419385000][SIAMMR3::NONLONFirstUseDate]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.2-MedicalDevicesImplants</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.2-MedicalDevicesImplants</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Entry Master Pattern Release 3 Full</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::C3.2-MedicalDevicesImplants][SIAMMR3::ENTRY.MPF][ContSys::HealthcareResource]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002823" MODIFIED="1401277002823" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">issue related to the health of a subject of care, as defined by a specific health care party
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOOtherCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOOtherCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for the general term &amp;apos;Characteristics&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.2.3-ImplantDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
Date when procedure was performed


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;first&amp;apos; and &amp;apos;use&amp;apos; &amp;lt;=
There is NO SNOMED code for&amp;apos; Implant date&amp;apos;</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::419385000][SIAMMR3::NONLONFirstUseDate]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002839" MODIFIED="1401277002839" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][DCM::CEN-EN13606-CLUSTER.ResultValues.v2][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.2.1-MedicalDeviceImplant</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">C3.2.2: Holds the result as Codedtext

Describes the patient&amp;apos;s implanted and external medical devices and equipment upon which their health status depends. Includes devices such as cardiac pacemakers, implantable fibrillators, prostheses, ferromagnetic bone implants, etc. of which the HP needs to be aware.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C3.2.1-MedicalDeviceImplant][SNOMED-CT::49062001][LOINC::55439-4]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.3-MajorSurgicalProcedures</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">List of Major surgical procedures in the past six months</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.3-MajorSurgery</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Entry Master Pattern Release 3 Full

Major surgical procedures in the past six months</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::C3.3-MajorSurgery][DCM::CEN-EN13606-ENTRY.HcActivity.v1][SIAMMR3::ENTRY.MPF][SIAMMR3::HcActivity]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">issue related to the health of a subject of care, as defined by a specific health care party
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002855" MODIFIED="1401277002855" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.3.1-ProcedureDescription</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">C3.3.2: Holds the result as Codedtext

Describes the type of procedure</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::257556004][LOINC::21968-3][SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOOtherCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOOtherCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for the general term &amp;apos;Characteristics&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.3.3-ProcedureDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;first&amp;apos; and &amp;apos;use&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C3.3.3-ProcedureDate][SNOMED-CT::419385000][SIAMMR3::NONLONFirstUseDate]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002870" MODIFIED="1401277002870" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.4-TreatmentRecommandations</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Treatment recommendations</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.4-TreatmentRecommendations</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Entry Master Pattern Release 3 Full</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::C3.4-TreatmentRecommendations][DCM::CEN-EN13606-ENTRY.HcActivity.v1][SIAMMR3::ENTRY.MPF][SIAMMR3::HcActivity]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">issue related to the health of a subject of care, as defined by a specific health care party
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: HealthActivity Original text: [HealthActivity]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Order, Execute, Assess, ResultCollection, Inference]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Therapeutic recommendations that do not include drugs (diet, physical exercise constraints, etc.)and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.4.1-DescriptionRecommendation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">C3.4.2Holds the result as Codedtext and as Description

Therapeutic recommendations that do not include drugs (diet, physical exercise constraints, etc.)</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C3.4.1-DescriptionRecommendation][SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002886" MODIFIED="1401277002886" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.5-AutonomyInvalidity</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.5-AutonomyInvalidity</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Entry Master Pattern Release 3 Full</p>
&#xa;
<p align="left"> Occurences {1..*} </p>
&#xa;
<p align="left">[epSOS::C3.5-AutonomyInvalidity][DCM::CEN-EN13606-ENTRY.PrHcCondition.v1][SIAMMR3::ENTRY.MPF][SIAMMR3::PrHcCondition]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="entry"/>
<node CREATED="1401277002901" MODIFIED="1401277002901" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation, Evaluation, Instruction, Action]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">issue related to the health of a subject of care, as defined by a specific health care party
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Order, Execute, Assess, ResultCollection, Inference]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C3.5.1-Autonomy/Invalidity</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">C3.5.2: Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C3.5.1-AutonomyInvalidity][SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002917" MODIFIED="1401277002917" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4-MedicationSummary</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1-ListOfCurrentMedicines</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Process ResultColection of Medicinal Product

There NO SNOMED code for &amp;apos;Current Medication&amp;apos;</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-ENTRY.PrRcMedicinalProductF.v3][LOINC::29549-3][LOINC::29550-1][SIAMMR3::ENTRY.MPF][SIAMMR3::PrRcMedicinalProduct]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Folder, Composition, Section, Entry, Cluster, Element, EHR-Extract]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation, Evaluation, Instruction, Action]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Order, Execute, Assess, ResultCollection, Inference]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPNamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos; Object &amp;apos; &amp;lt;=

Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v3][SIAMMR3::MPNamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPNONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics

=&amp;gt; No codes for Characteristics of an OBJECT &amp;lt;=
&amp;gt; Organisation or Physical or non physical</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPNONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPNONLOUnstructured</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the unstructuredCharacteristics
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPNONLOUnstructured]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIMPLE_TEXT</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ActiveIngredient</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPNONLONames][SIAMMR3::ActiveIngredient]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1.1-ActiveIngredient</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C4.1.1-ActiveIngredient][SNOMED-CT::272734009][SIAMMR3::MPNONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002933" MODIFIED="1401277002933" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPNONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPNONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: ActiveIngredient Original text: [ActiveIngredient]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPNONLOOtherCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOOtherCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for the general term &amp;apos;Characteristics&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPNONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1.8-DateOfOnset</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;first&amp;apos; and &amp;apos;use&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C4.1.8-DateOfOnset][SNOMED-CT::419385000][SIAMMR3::MPNONLONFirstUseDate]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RCMedicinalProductInfo</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">RCMedicinalProduct

Defines data about any Medicinal Product
This Complex Cluster Model is produced on the basis of CEN General Purpose Components (GPICS) and openEHR CKM examples.

The name of the product will be coded in Results as part of the WHAT
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.RCMedicinalProductInfo.v1]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPProductCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPProductCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1.4-PharmaceuticalDoseForm</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The dose form of the medicinal product.
Container type
EXAMPLES (codes for)
		   tablet; 
		   solution; 
		   cream; 
		   combination pack; 
		   patch. 
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPPNProductFormCode][SIAMMR3::C4.1.4-PharmaceuticalDoseForm]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPPNProductFormCode</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The dose form of the medicinal product.
Container type
EXAMPLES (codes for)
		   tablet; 
		   solution; 
		   cream; 
		   combination pack; </p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPDoseAdministration</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1.7-DurationOfTreatment</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">administration occurs.
EXAMPLES
5 h – where instruction = 10 mg/l infuse at 50 ml/h for 5 h;
2 d where instruction = 2 capsules 4 times per day for 2 d.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C4.1.7-DurationOfTreatment][SIAMMR3::MPDAEffectiveTime]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPDAEffectiveTime</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">administration occurs.
EXAMPLES
5 h – where instruction = 10 mg/l infuse at 50 ml/h for 5 h;
2 d where instruction = 2 capsules 4 times per day for 2 d.
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Units: [a, mo, wk, d, h, min, s]</p>
</body>
</html></richcontent>
<icon BUILTIN="balance"/>
</node>
</node>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1.3-Strength</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The amount of the medicinal product given in one administration event.
EXAMPLES 5 ml, 2 tablets, 2 puffs.
[PM: In absolute terms or as %?]
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPDADoseQuantity][SIAMMR3::C4.1.3-Strength]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPDADoseQuantity</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="balance"/>
</node>
</node>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1.5-NumberOfUnitsPerIntake</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MPDNumberOfUnitsPerIntake][SIAMMR3::C4.1.5-NumberOfUnitsPerIntake]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NumberOfUnitsPerIntake</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="numero"/>
</node>
</node>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1.6-FrequencyOfIntakes</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>FrequencyOfIntakes</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Units: [[iU]/d, g/h, [iU]/min]</p>
</body>
</html></richcontent>
<icon BUILTIN="balance"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002948" MODIFIED="1401277002948" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MPNOUniqueIdentifiers</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">  CLUSTER that codes for the set of Unique Identifiers and their attributes for this entity

=&amp;gt; There is NO SNOMED PRIMITIVE for&amp;apos; Unique&amp;apos; &amp;lt;=
&amp;gt; And the subordinate items  Designation/name, GeoArea, Issuer, Type
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;unique&amp;apos; &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::118522005][LOINC::52417-3][SIAMMR3::MPNOUniqueIdentifiers]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C4.1.2-ActiveIngredientIDCode</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.2: SubjectIdentifier
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C4.1.2-ActiveIngredientIDCode][SIAMMR3::NOUIDDesignation]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDDesignation</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.2: SubjectIdentifier</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.5: SubjectIdentifier Type

Codes for type of user/service/etc.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NOUIDType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOUIDType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ISO 2220: 8.5: SubjectIdentifier Type

Codes for type of user/service/etc.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C8-DiagnosticTests</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C8.1-Bloodgroup</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">PhysicalFindingsVitalSigns</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-ENTRY.PrRcHealthObservedCondition.v1][SIAMMR3::ENTRY.MPF][SIAMMR3::PrRcHealthObservedCondition]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse][SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics

=&amp;gt; No codes for Characteristics of an OBJECT &amp;lt;=
&amp;gt; Organisation or Physical or non physical</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: Measurement Original text: [Measurement]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LocalisationInTime</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This CLUSTER model codes for the Localistation in Time of the modeled activity.
Both as Absolute point in time or Relative to an Anchor point in time.
It is possible to code for a single point in time or a period.

=&amp;gt; Which SNOMED time code is appropriate? &amp;lt;=


Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data/</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::410670007][SNOMED-CT::410669006][SIAMMR3::LocalisationInTime]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LITAbsolute</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt;NO SNOMED CODES for all subordinate items&amp;lt;=


Codes for Absolute points in time as Duration and/or Begin adn End times

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::LITAbsolute][SIAMMR3::LocalisationInTime]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C8.1.1-ResultOfBloodgroup</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the begin point in time.

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C8.1.1-ResultOfBloodgroup][SNOMED-CT::398201009][SIAMMR3::LITAbsBegin]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002964" MODIFIED="1401277002964" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LITAbsBegin</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the begin point in time.

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data

</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][DCM::CEN-EN13606-CLUSTER.ResultValues.v2][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C8.1.1-BloodGroup</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::C8.1.1-BloodGroup]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C5-SocialHistory</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C5.1-SocialHistory</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">MainPattern to be specialised</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[epSOS::C5.1-SocialHistory][DCM::CEN-EN13606-ENTRY.PrHcRUHISH.v1][SIAMMR3::ENTRY.MPF]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277002979" MODIFIED="1401277002979" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Order, Execute, Assess, ResultCollection, Inference]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Diagnostic, Therapeutic, Administrative, Management, ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Name]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::CodingSystem1Version]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
&#xa;
<p align="left">[SIAMMR3::SIAMMVersion]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValue</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Social history observatins re;ated to smoking, alcohol, and diet</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C5.1.1-SocialHistory</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext

Social History observations related tosmoking, alcohol, and diet</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::C5.1.1-SocialHistory][SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultCodedtext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the result as Codedtext</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::ResultCodedtext]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][DCM::CEN-EN13606-CLUSTER.NamedObject.v1][LOINC::52458-7][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.NONLOCharacteristics.v1][SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;Name&amp;apos; and &amp;apos;NonLiving&amp;apos; &amp;lt;=
=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;Object&amp;apos;, Non-Living&amp;apos;

Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: HistorySocial Original text: [HistorySocial]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: History Original text: [History]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOOtherCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOOtherCharacteristics

=&amp;gt; NO SNOMED PRIMITIVE for the general term &amp;apos;Characteristics&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOOtherCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C5.1.2-ReferenceDateBegin</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used


=&amp;gt; There is NO LOINC PRIMITIVE for &amp;apos;first&amp;apos; and &amp;apos;use&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::C5.1.2-ReferenceDateBegin][SNOMED-CT::419385000]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONFirstUseDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Date first used
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C5.1.3-ReferenceDateRangeEnd</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the date to be decomissioned

=&amp;gt; NO SNOMED CODE for &amp;apos;Decommission&amp;apos; of a &amp;apos;NonLiving Object&amp;apos; &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[epSOS::C5.1.3-ReferenceDateRangeEnd][SIAMMR3::NONLONDecommissionDate]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONDecommissionDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the date to be decomissioned
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C6-PregnancyHistory</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C6.1-PregnancyHistory</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">An ad-hoc Entry.
At this moment there is NO formal Pregnancy Model.</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::15592002][DCM::CEN-EN13606-ENTRY.PregnancyHistory.v1][LOINC::67471-3]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C6.1.1-PregnancyDeliveryDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Date on which the woman is due to give birth, Year, month, and dat are required (eg 01/01/2014)

There was NO SNOMED code for &amp;apos;Birth date&amp;apos;</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[LOINC::21112-8]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C6.1.1-PregnancyDeliveryDate</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-CLUSTER.MetaDataArtefact.v2][SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIMPLE_TEXT</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ontSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ReferencesCodingSystems</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Used to define as part of the archetype a coding system that is referenced inside the archetype</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ReferencesCodingSystems]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Container for CodingSystem1.
Can be repeated</p>
&#xa;
<p align="left"> Occurences {0..*} </p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Name</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The name (URL) of the codings system</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIMPLE_TEXT</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>CodingSystem1Version</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of the coding system</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003026" MODIFIED="1401277003026" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIMPLE_TEXT</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Pattern: .*</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>SIAMMVersion</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">The version of SIAMM that is used</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: [Rel3]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C7-PhysicalFindings</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="section"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C7.1-Vitalsigns</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..*} </p>
</body>
</html></richcontent>
<icon BUILTIN="section"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C7.1.1-SystolicBloodPressure</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">PhysicalFindingsVitalSigns</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-ENTRY.PrRcHealthObservedCondition.v1][SIAMMR3::ENTRY.MPF]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: HealthObservedCondition Original text: [HealthObservedCondition]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse][SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C7.1.1-SystolicBloodPressure</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics

=&amp;gt; No codes for Characteristics of an OBJECT &amp;lt;=
&amp;gt; Organisation or Physical or non physical</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultNumeric</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; NO SNOMED CODE for &amp;apos;NUmeric result and its subordinate items&amp;apos; &amp;lt;=

Holds one numeric result

Codes for:
	•	Numeric result including
	•	Units of Measurement via Data Type
	•	Normal range: the range of normal values as publsihed
	•	Signal range: the used to generate alerts
	•	Allowed range: the Multitude that can be entered as number

The WHAT: NamedObject will hold the Name attached to the numeric result.
e.g.
WHAT:NamedObject...NameType=‘Finding:Lab-Test’
WHAT:NamedObject...Name=‘Glucose concentration’
WHAT:ResultValueNumericResult=’7.4’, Units=’mM/L’
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::ResultNumeric]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RNValue</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the numeric value with its Units of Measurement

CLUSTER model that codes for a Number and Units of Measurement HL7: UCAM
And Number attributes such as:
- Precision
- Scale
- Sensitivity
- Specificity
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::RNValue]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RNValueNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Number including via the Data Type the Units of Measurement
(see HL7 UCUM)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::RNValueNumber]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RNValueNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Number including via the Data Type the Units of Measurement
(see HL7 UCUM)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="balance"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LocalisationInTime</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This CLUSTER model codes for the Localistation in Time of the modeled activity.
Both as Absolute point in time or Relative to an Anchor point in time.
It is possible to code for a single point in time or a period.

=&amp;gt; Which SNOMED time code is appropriate? &amp;lt;=


Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data/</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::410670007][SNOMED-CT::410669006][SIAMMR3::LocalisationInTime]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LITAbsolute</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt;NO SNOMED CODES for all subordinate items&amp;lt;=


Codes for Absolute points in time as Duration and/or Begin adn End times

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::LITAbsolute][SIAMMR3::LocalisationInTime]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C7.1.2-DateSystolicBloodPressureMeasurement</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the begin point in time.

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C7.1.2-DateSystolicBloodPressureMeasurement][SNOMED-CT::398201009][SIAMMR3::LITAbsBegin]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LITAbsBegin</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the begin point in time.

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data

</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C7.1.2-DiastolicBloodPressure</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">PhysicalFindingsVitalSigns</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[DCM::CEN-EN13606-ENTRY.PrRcHealthObservedCondition.v1][SIAMMR3::ENTRY.MPF]</p>
</body>
</html></richcontent>
<icon BUILTIN="entry"/>
<node CREATED="1401277003042" MODIFIED="1401277003042" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>MetaDataArtefact</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This SIAMM sub-pattern is a Cluster Model.
It is used in the SIAMM Main ENTRY Pattern.
Its purpose is to describe the nature of the artefact: reference model used, class of the reference model, name of the class, binding to ContSys, sub-pattern used, intended use of the artefact, context in which the artefact will be used, etc.
This Cluster Model defines:
	•	the generic Class name from the Target Reference Model
	•	the name given to that generic class from the TrM
	•	the context of the artefact when it is used to document events during the care treatment cycle
	•	the use of the rate fact. Is it defined for use for persistence, querying or presentation

In the case of an ENTRY class from the TrM the possible FUnctions are: Order, Execution, Observation of results and Assessment of any procedure.

All the choices in this ToA branch of they generic semantic pattern define the specific pattern to be used.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::MetaDataArtefact]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model (e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModel</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Provide the name + version of the Reference Model
(e.g. En13606:2008 or SIAMM:2013, etc)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [En13606:2008]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModel]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClass</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Specify what class of the RM is used as starting point:

	•	EHR-EXtract
	•	Folder
	•	Composition
	•	Section
	•	Entry
	•	Cluster
	•	Element
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Entry]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClass]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ArtefactUse</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the use of the artefact

	•	Persistence
	•	Querying
	•	InputExchange
	•	OutputExchange
	•	Presentation
	•	DataCapture
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Persistence, Querying, InputExchange, OutputExchange, Presentation, DataCapture]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes fro the kind of artefact:
	•	Observation
	•	Evaluation
	•	Instruction
	•	Action</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [Observation]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept

=&amp;gt; Should ContSysCODES become part of SNOMED &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassName]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>TargetReferenceModelClassType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the binding with one ContSys concept
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: HealthObservedCondition Original text: [HealthObservedCondition]</p>
&#xa;
<p align="left">[SIAMMR3::TargetReferenceModelClassType]</p>
</body>
</html></richcontent>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessPattern</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for one of the five SIAMM patterns for an ENTRY class

	•	Order
	•	Execute
	•	Assess
	•	ResultCollection (summary)
	•	Inference
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ResultCollection]</p>
&#xa;
<p align="left">[SIAMMR3::ProcessPattern]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ProcessContext</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the process context the artefact is used in

	•	Diagnostic
	•	Therapeutic
	•	Administrative
	•	Management
	•	ReUse</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Original text: [ReUse]</p>
&#xa;
<p align="left">[SIAMMR3::ArtefactUse][SIAMMR3::ProcessContext]</p>
</body>
</html></richcontent>
<icon BUILTIN="textfield"/>
</node>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NamedObject</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Entity that is part of a process
Each Entity and its characteristics can be coded.
Describes &amp;apos;demographic data about living and non-licving objects:
	•	ID&amp;apos;s
	•	Names
	•	Characteristics
	•	LIfeCycle
	•	Location
	•	Particicipations/Roles


Aligned with:
	•	ISO TS 22220: Health Informatics _ identification of Subjects of health care
	•	CEN/ISO ContSys 12940

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::272734009][SIAMMR3::NamedObject]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOCharacteristics</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLOCharacteristics

=&amp;gt; No codes for Characteristics of an OBJECT &amp;lt;=
&amp;gt; Organisation or Physical or non physical</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOCharacteristics]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type.
e.g. Procedure for something specific
When NONLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

=&amp;gt;NO SNOMED CODE for a Name of any Non-Living Object (Physical or logical &amp;lt;=
The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLOName]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLOName</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Code for the Name of the Non Living Object Type. 
e.g. Procedure for something specific
When NLONNameType= Intervention:Prescription procedure
Then in order to prescribe a Medicinal product NLOName=Medicinal Product

There is NO SNOMED CODE for &amp;apos;Diastolic Blood Pressure&amp;apos;


The CLUSTER ResultValues via its COMPLEX CLUSTER model will allow to specify the specific medicinal product.
Since in the Order pattern this has the function of detailing the precise medicinal product.
</p>
&#xa;
<p align="left"> Occurences {1} </p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::NONLONameType]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NONLONameType</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NONLONameType</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left"> Original text: Measurement Original text: [Measurement]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="tag_red"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultValues</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">ResultValues.

Minimally one, ,aximally choice can occur only once.
Rules need to be spcified on more detailed allowed behaviors.

Minimally one result is allowed and optionally in addition: Comments and SCN.</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SNOMED-CT::423100009][SIAMMR3::ResultValues]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>ResultNumeric</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; NO SNOMED CODE for &amp;apos;NUmeric result and its subordinate items&amp;apos; &amp;lt;=

Holds one numeric result

Codes for:
	•	Numeric result including
	•	Units of Measurement via Data Type
	•	Normal range: the range of normal values as publsihed
	•	Signal range: the used to generate alerts
	•	Allowed range: the Multitude that can be entered as number

The WHAT: NamedObject will hold the Name attached to the numeric result.
e.g.
WHAT:NamedObject...NameType=‘Finding:Lab-Test’
WHAT:NamedObject...Name=‘Glucose concentration’
WHAT:ResultValueNumericResult=’7.4’, Units=’mM/L’
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SIAMMR3::ResultNumeric]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RNValue</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Holds the numeric value with its Units of Measurement

CLUSTER model that codes for a Number and Units of Measurement HL7: UCAM
And Number attributes such as:
- Precision
- Scale
- Sensitivity
- Specificity
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::RNValue]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RNValueNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Number including via the Data Type the Units of Measurement
(see HL7 UCUM)
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::RNValue]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>RNValueNumber</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the Number including via the Data Type the Units of Measurement
(see HL7 UCUM)
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="balance"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LocalisationInTime</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">This CLUSTER model codes for the Localistation in Time of the modeled activity.
Both as Absolute point in time or Relative to an Anchor point in time.
It is possible to code for a single point in time or a period.

=&amp;gt; Which SNOMED time code is appropriate? &amp;lt;=


Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data/</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left">[SNOMED-CT::410670007][SNOMED-CT::410669006][SIAMMR3::LocalisationInTime]</p>
</body>
</html></richcontent>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LITAbsolute</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt;NO SNOMED CODES for all subordinate items&amp;lt;=


Codes for Absolute points in time as Duration and/or Begin adn End times

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data
</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[SIAMMR3::LITAbsolute][SIAMMR3::LocalisationInTime]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="cluster"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>C7.1.2-DateDiastolicBloodPressureMeasurement</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the begin point in time.

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data

</p>
&#xa;
<p align="left"> Occurences {1} </p>
&#xa;
<p align="left">[epSOS::C7.1.2-DateDiastolicBloodPressureMeasurement][SNOMED-CT::398201009][SIAMMR3::LITAbsBegin]</p>
</body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="elemento"/>
<node CREATED="1401277003057" MODIFIED="1401277003057" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>LITAbsBegin</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">Codes for the begin point in time.

Rules:
A point in time has Begin=End time
When Begin=End it is a point in time.
When Duration= 0 it is a point in time where Begin=End.

A period in time has Begin and End time
or Begin + Duration
0r End-Duration
A pont in time has Begin=End time

Preferred is Begin and End time for storing and retrieving data

</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="date"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
