<map version="0.9.0">
<!-- Freemind mindmap generated with LinkEHR editor (www.linkehr.com) on Sun Feb 23 13:04:26 CET 2014 -->
<node BACKGROUND_COLOR="#ccccff" CREATED="1393157066418" MODIFIED="1393157066418" POSITION="right">
<richcontent TYPE="NODE"><html><head/><body><p>
<b>NOGeographicalPosition</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p>NOGeographicalPosition</p></body></html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="cluster"/>
<node CREATED="1393157066418" FOLDED="true" ID="DESCRIPTION" MODIFIED="1393157066418" TEXT="DESCRIPTION" POSITION="left">
<icon BUILTIN="pencil"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="original_author">
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="email: g.freriks@e-recordservices.eu"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="organisation: ERS B.V."/>
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="name: Gerard Freriks"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="date: 20140223"/>
</node>
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="lifecycle_state: Draft"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="purpose: Document the geo position"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="use: in SIAMM"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" TEXT="copyright: ERS B.V."/>
</node>
<node CREATED="1393157066418" MODIFIED="1393157066418" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOGPLatitude</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;latitude&amp;apos; &amp;lt;=
</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOGPLatitude</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOGPLatitude

=&amp;gt; NO SNOMED code found &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Units: deg</p>
</body>
</html></richcontent>
<icon BUILTIN="balance"/>
</node>
</node>
<node CREATED="1393157066418" MODIFIED="1393157066418" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOGPLongitude</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">=&amp;gt; There is NO SNOMED PRIMITIVE for &amp;apos;longitude&amp;apos; &amp;lt;=</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOGPLongitude</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOGPLongitude</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Units: deg</p>
</body>
</html></richcontent>
<icon BUILTIN="balance"/>
</node>
</node>
<node CREATED="1393157066418" MODIFIED="1393157066418" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOGPAltitude</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

<p align="left"> Occurences {0..1} </p>
</body>
</html></richcontent>
<icon BUILTIN="elemento"/>
<node CREATED="1393157066418" MODIFIED="1393157066418" POSITION="right" BACKGROUND_COLOR="#ccccff" STYLE="bubble">
<edge COLOR="#006666" STYLE="bezier" WIDTH="2"/>
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
<p>
<b>NOGPAltitude</b></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>

    <p align="left">NOGPAltitude</p>
&#xa;
<p align="left"> Occurences {0..1} </p>
&#xa;
<p align="left"> Units: deg</p>
</body>
</html></richcontent>
<icon BUILTIN="balance"/>
</node>
</node>
</node>
</map>
